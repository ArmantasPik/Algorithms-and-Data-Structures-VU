The files that are need to be able to use
the queue ADT are queue.c and queue.h.
Queue.h has all the information specified on
how to use the queue.

Main.c demonstrates how the queue is used and
makefile helps to compile all of the files together
